import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { Miniflare } from 'miniflare';
import { makeOperation, makeProject, PitchProof } from '../server/pitchproof';
import { Store } from '../server/store';
import { AppError, hash, randomToken } from '../server/errors';
import { assertSameOrigin, requestJson, resolveActor } from '../server/identity';
import { normalizeEntity, normalizeEvidence, insightsParameters, searchQloo } from '../server/providers/qloo';
import { modelConfiguration, requireProviders, validateDirections } from '../server/providers/synthesis';
import { parseCommand, parseProjectInput } from '../server/validation';
import type { Command, Evidence, Project } from '../lib/pitchproof-types';
const input = { brief: { product: 'Stride', description: 'Running shoes made for city running', category: 'Running footwear', market: 'London', audience: 'City runners', objective: 'Launch', constraints: '', website: '' }, references: [{query:'Nike',role:'competitor'},{query:'Aesop',role:'aesthetic'},{query:'Patagonia',role:'audience'}] } as const;
const make = () => makeProject(parseProjectInput(input));
test('agencies can label multiple distinct reference brands with the same role',()=>{
  const sameRole={...input,references:input.references.map(reference=>({...reference,role:'competitor'}))};
  const parsed=parseProjectInput(sameRole);
  assert.equal(parsed.references.length,3);
  assert.ok(parsed.references.every(reference=>reference.role==='competitor'));
});
function confirmed(): Project { const p=make(); p.references.forEach((r,i)=>r.entity={id:`entity-${i}`,name:r.query,type:'urn:entity:brand',description:'',image:null,url:null}); return p; }
function command(p: Project, value: Command, commandId = randomToken()) { return { ...value, expectedVersion:p.version, commandId }; }
let mf: Miniflare; let db: D1Database; let store: Store;
before(async()=>{
  mf = new Miniflare({ modules:true, script:'export default { fetch() { return new Response("ok"); } }', compatibilityDate:'2026-05-01', d1Databases:['DB'] });
  db = await mf.getD1Database('DB') as unknown as D1Database;
  await db.exec(`CREATE TABLE projects (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, version INTEGER NOT NULL, snapshot_json TEXT NOT NULL, updated_at TEXT NOT NULL); CREATE TABLE sessions (token_hash TEXT PRIMARY KEY, owner_id TEXT NOT NULL, expires_at INTEGER NOT NULL); CREATE TABLE command_receipts (project_id TEXT NOT NULL, owner_id TEXT NOT NULL, command_id TEXT NOT NULL, request_hash TEXT NOT NULL, result_version INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(project_id,command_id)); CREATE TABLE reference_candidates (token_hash TEXT PRIMARY KEY, owner_id TEXT NOT NULL, project_id TEXT NOT NULL, slot INTEGER NOT NULL, input_hash TEXT NOT NULL, query TEXT NOT NULL, entity_json TEXT NOT NULL, expires_at INTEGER NOT NULL); CREATE TABLE provider_usage (owner_id TEXT NOT NULL, day TEXT NOT NULL, calls INTEGER NOT NULL, PRIMARY KEY(owner_id,day));`);
  store = new Store(db);
});
after(async()=>{ await mf.dispose(); });
test('insufficient evidence cannot retry the same impossible synthesis or spend another provider call', async()=>{
  const p=confirmed(); p.operation=makeOperation(p,'research');
  p.operation.steps=p.operation.steps.map(step=>({...step,status:'complete',evidenceIds:[],error:'No supporting evidence returned'}));
  p.operation.phase='synthesis'; p.operation.state='failed'; p.operation.failureCode='INSUFFICIENT_EVIDENCE'; p.status='error';
  await store.create('sparse-retry-owner',p);
  const service=new PitchProof(store,{QLOO_API_KEY:'synthetic-key',MODEL_API_KEY:'synthetic-model-key'});
  const before=await db.prepare('SELECT SUM(calls) AS total FROM provider_usage').first<{total:number|null}>();
  await assert.rejects(()=>service.execute('sparse-retry-owner',p.id,command(p,{action:'retry'})),error=>error instanceof AppError&&error.code==='INSUFFICIENT_EVIDENCE');
  const after=await db.prepare('SELECT SUM(calls) AS total FROM provider_usage').first<{total:number|null}>();
  assert.equal(after?.total,before?.total);
  assert.equal((await store.read('sparse-retry-owner',p.id)).operation?.state,'failed');
});
test('Qloo normalization retains metric semantics and only supported geography', ()=>{
  assert.equal(normalizeEntity({entity_id:'x',name:'Example',properties:{image:{url:'javascript:alert(1)'},url:'https://example.com',description:'A real description'}})?.image,null);
  assert.equal(normalizeEntity({entity_id:'x',name:'Example',properties:{image:{url:'https://example.com/photo.jpg'}}})?.image,'https://example.com/photo.jpg');
  const p=confirmed(); const op=makeOperation(p,'research'); const step=op.steps[0];
  const evidence=normalizeEvidence({results:{entities:[{entity_id:'result-1',name:'Result',query:{measurements:{affinity:0.62}}}]}},op,step);
  assert.deepEqual(evidence[0].score,{value:0.62,metric:'query.measurements.affinity'});
  assert.equal(evidence[0].context.geographyApplied,false);
  assert.match(evidence[0].observation,/not measured customers/);
  assert.equal(insightsParameters('artist',['x'],'London')['filter.location.query'],undefined);
  assert.equal(insightsParameters('place',['x'],'London')['filter.location.query'],'London');
});
test('missing provider credentials fail without synthetic evidence',async()=>{
  assert.throws(()=>requireProviders({}),e=>e instanceof AppError && e.code==='QLOO_NOT_CONFIGURED');
  await assert.rejects(()=>searchQloo(undefined,'Nike'),e=>e instanceof AppError&&e.code==='QLOO_NOT_CONFIGURED');
  assert.equal(modelConfiguration({MODEL_API_KEY:'x'}).model,'gemini-2.5-flash');
  assert.equal(modelConfiguration({MODEL_API_KEY:'x',MODEL_PROVIDER:'arbitrary'}).configured,false);
});
test('synthesis rejects hallucinated citations and duplicate creative directions',()=>{
  const evidence=[{id:'real-1'},{id:'real-2'}] as Evidence[];
  const direction={title:'One direction',hook:'Creative hook',audienceHypothesis:'A hypothesis',strategy:'A strategy',visuals:{description:'Visual treatment',palette:['#112233','#445566','#778899'],references:['Example']},channels:['Social'],claims:[{text:'Supported association',evidenceIds:['real-1']},{text:'Another association',evidenceIds:['real-2']}],testPlan:{hypothesis:'A practical hypothesis',variants:['First execution','Second execution'],metric:'Click-through rate',successCriterion:'Compare against baseline'},limitations:['Associations are not causal','Customers must validate']};
  const output={directions:[direction,{...direction,title:'Two direction',hook:'Second creative hook'},{...direction,title:'Three direction',hook:'Third creative hook'}]};
  assert.equal(validateDirections(output,evidence).length,3);
  assert.throws(()=>validateDirections({directions:[direction,direction,direction]},evidence),e=>e instanceof AppError&&e.code==='DUPLICATE_DIRECTIONS');
  const bad=structuredClone(output); bad.directions[0].claims[0].evidenceIds=['invented'];
  assert.throws(()=>validateDirections(bad,evidence),e=>e instanceof AppError&&e.code==='INVALID_CITATIONS');
});
test('anonymous sessions have hashed cookies and other owners cannot read projects',async()=>{
  const first=await resolveActor(new Request('https://pitchproof.example/api/projects'),db); assert.match(first.cookie!,/HttpOnly; SameSite=Lax/); assert.match(first.cookie!,/Secure/);
  const cookie=first.cookie!.split(';')[0]; const token=cookie.split('=')[1];
  assert.ok(await db.prepare('SELECT token_hash FROM sessions WHERE token_hash = ?').bind(await hash(token)).first());
  const second=await resolveActor(new Request('https://pitchproof.example/api/projects',{headers:{cookie}}),db); assert.equal(first.owner,second.owner);
  const p=make(); await store.create(first.owner,p);
  await assert.rejects(()=>store.read('someone-else',p.id),e=>e instanceof AppError&&e.status===404);
  const platform=await resolveActor(new Request('https://pitchproof.example/api/projects',{headers:{'oai-authenticated-user-id':'stable-id','oai-authenticated-user-email':'person@example.com'}}),db); assert.match(platform.owner,/^platform:/); assert.equal(platform.cookie,null);
});
test('same origin and bounded JSON are enforced',async()=>{
  assert.throws(()=>assertSameOrigin(new Request('https://pitchproof.example/api/projects',{method:'POST',headers:{origin:'https://attacker.example','content-type':'application/json'},body:'{}'})),e=>e instanceof AppError&&e.status===403);
  assert.doesNotThrow(()=>assertSameOrigin(new Request('https://pitchproof.example/api/projects',{method:'POST',headers:{origin:'https://pitchproof.example','content-type':'application/json'},body:'{}'})));
  await assert.rejects(()=>requestJson(new Request('https://pitchproof.example',{method:'POST',body:'x'.repeat(17000)})),e=>e instanceof AppError&&e.status===413);
});
test('CAS rejects stale writes without receipts and duplicate command is idempotent',async()=>{
  const service=new PitchProof(store,{}); const owner='cas-owner'; const p=make(); await store.create(owner,p);
  const cmd=command(p,{action:'cancel'}); const next=await service.execute(owner,p.id,cmd); assert.equal(next.version,1);
  assert.equal((await service.execute(owner,p.id,cmd)).version,1);
  await assert.rejects(()=>service.execute(owner,p.id,{...cmd,action:'start_research'}),e=>e instanceof AppError&&e.code==='COMMAND_REUSED');
  const stale=structuredClone(p); stale.title='must not replace';
  await assert.rejects(()=>store.save(owner,0,stale,{commandId:'stale-command',requestHash:'stale'}),e=>e instanceof AppError&&e.code==='STALE_VERSION');
  assert.equal(await store.receipt(owner,p.id,'stale-command','stale'),false);
  assert.notEqual((await store.read(owner,p.id)).title,'must not replace');
});
test('candidate confirmation binds owner, project, slot, and current references',async()=>{
  const owner='token-owner'; const p=make(); await store.create(owner,p); const token=randomToken(); const entity={id:'official-brand',name:'Official',type:'urn:entity:brand',description:'',image:null,url:null};
  await store.putCandidate(owner,p,0,'Official query',entity,token);
  await assert.rejects(()=>store.candidate('other',p,0,token),e=>e instanceof AppError&&e.code==='EXPIRED_CANDIDATE');
  await assert.rejects(()=>store.candidate(owner,p,1,token),e=>e instanceof AppError&&e.code==='EXPIRED_CANDIDATE');
  const updated=structuredClone(p);updated.references[0].query='Different';
  await assert.rejects(()=>store.candidate(owner,updated,0,token),e=>e instanceof AppError&&e.code==='EXPIRED_CANDIDATE');
  const service=new PitchProof(store,{}); const result=await service.execute(owner,p.id,command(p,{action:'confirm_reference',slot:0,token})); assert.equal(result.references[0].entity?.id,'official-brand');assert.equal(result.references[0].query,'Official query');
});
test('advance persists one request, resumes completed steps and retains research on failure',async()=>{
  const owner='research-owner'; let p=confirmed(); await store.create(owner,p);
  const service=new PitchProof(store,{QLOO_API_KEY:'test-key',MODEL_API_KEY:'test-key'});
  p=await service.execute(owner,p.id,command(p,{action:'start_research'}));assert.ok(p.operation);const total=p.operation.steps.length;
  const original=globalThis.fetch; const urls:string[]=[];
  globalThis.fetch=async input=>{urls.push(String(input));return Response.json({results:{entities:[{entity_id:'observed-1',name:'Observed',query:{affinity:0.34}},{entity_id:'observed-2',name:'Another'}]}});};
  try {
    p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(urls.length,1);assert.equal(p.evidence.length,2);assert.equal(p.operation?.steps.filter(s=>s.status==='complete').length,1);assert.equal(p.operation?.leaseToken,null);
    p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(urls.length,2);assert.equal(p.evidence.length,4);assert.equal(p.operation?.steps.length,total);
    globalThis.fetch=async()=>new Response('upstream details with secret',{status:500});
    p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(p.status,'error');assert.equal(p.evidence.length,4);assert.equal(p.operation?.leaseToken,null);assert.doesNotMatch(p.error!,/secret/);
    p=await service.execute(owner,p.id,command(p,{action:'retry'}));assert.equal(p.operation?.steps.filter(s=>s.status==='complete').length,2);assert.equal(p.status,'researching');
    p=await service.execute(owner,p.id,command(p,{action:'cancel'}));assert.equal(p.operation,null);assert.equal(p.evidence.length,4);
  } finally {globalThis.fetch=original;}
});
test('cancellation prevents an already running provider from committing evidence',async()=>{
  const owner='cancel-owner'; let p=confirmed(); await store.create(owner,p); const service=new PitchProof(store,{QLOO_API_KEY:'key',MODEL_API_KEY:'key'});p=await service.execute(owner,p.id,command(p,{action:'start_research'}));
  const original=globalThis.fetch;let release!:()=>void; let called!:()=>void; const started=new Promise<void>(r=>called=r);const pending=new Promise<void>(r=>release=r);
  globalThis.fetch=async()=>{called();await pending;return Response.json({results:{entities:[{entity_id:'late',name:'Late result'}]}});};
  try { const advancing=service.execute(owner,p.id,command(p,{action:'advance'}));await started;const current=await store.read(owner,p.id);await service.execute(owner,p.id,command(current,{action:'cancel'}));release();const result=await advancing;assert.equal(result.operation,null);assert.equal(result.evidence.length,0); }finally{globalThis.fetch=original;release?.();}
});
test('editing inputs preserves historical evidence and unconfirms only changed references',async()=>{
 const owner='edit-owner';const p=confirmed();p.evidence=[{id:'historic'}] as Evidence[];await store.create(owner,p);const service=new PitchProof(store,{});const refs=p.references.map(({query,role})=>({query,role}));refs[1].query='New aesthetic';const result=await service.execute(owner,p.id,command(p,{action:'update_brief',brief:{...p.brief,product:'Updated'},references:refs}));assert.equal(result.evidence[0].id,'historic');assert.ok(result.references[0].entity);assert.equal(result.references[1].entity,null);assert.equal(result.title,'Updated');
});
test('command parsing accepts valid actions and rejects malformed control and feedback',()=>{
 assert.equal(parseCommand({action:'advance',expectedVersion:0,commandId:'command-123'}).action,'advance');
 assert.throws(()=>parseCommand({action:'revise',directionId:'x',feedback:'bad',expectedVersion:0,commandId:'command-123'}));
 assert.throws(()=>parseCommand({action:'advance',expectedVersion:-1,commandId:'command-123'}));
});
test('complete research, synthesis, feedback-led revision and decisions persist with immutable history',async()=>{
 const owner='workflow-owner';let p=confirmed();await store.create(owner,p);const service=new PitchProof(store,{QLOO_API_KEY:'test',MODEL_API_KEY:'test'});const original=globalThis.fetch;let qlooCalls=0;let plannerCalls=0;let modelCalls=0;let revisionPrompt='';
 globalThis.fetch=async (url,init)=>{
  if(String(url).includes('/v2/insights')){qlooCalls++;return Response.json({results:{entities:Array.from({length:6},(_,i)=>({entity_id:`research-${qlooCalls}-${i}`,name:`Observed ${qlooCalls}/${i}`,query:{affinity:0.5}}))}});}
  const body=JSON.parse(String(init?.body));const text=body.contents[0].parts[0].text;
  if(text.startsWith('Choose the TWO')){plannerCalls++;assert.match(text,/local podcast campaign/);return Response.json({candidates:[{content:{parts:[{text:JSON.stringify({categories:['podcast','place']})}]}}]});}
  modelCalls++;const payload=JSON.parse(text);if(payload.feedback)revisionPrompt=text;const ids=payload.evidence.map((e:Evidence)=>e.id);
  const directions=Array.from({length:3},(_,i)=>({title:`Strategy ${i+1} generation ${modelCalls}`,hook:`Creative hook ${i+1}`,audienceHypothesis:'Taste reference hypothesis to validate',strategy:`Campaign strategy ${i+1}`,visuals:{description:`Visual treatment ${i+1}`,palette:['#112233','#445566','#778899'],references:['Observed inspiration']},channels:['Organic social'],claims:[{text:'The reference is associated with this entity',evidenceIds:[ids[0]]},{text:'A second association informs this test',evidenceIds:[ids.at(-1)]}],testPlan:{hypothesis:`A creative hypothesis ${i+1}`,variants:['First treatment','Second treatment'],metric:'Qualified click-through',successCriterion:'Compare each variant against control'},limitations:['Associations are not purchase probabilities','Validate with actual customers']}));
  return Response.json({candidates:[{content:{parts:[{text:JSON.stringify({directions})}]}}]});
 };
 try{
  p=await service.execute(owner,p.id,command(p,{action:'start_research'}));while(p.operation)p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(p.status,'ready');assert.equal(p.generations.length,1);assert.equal(qlooCalls,9);assert.equal(modelCalls,1);assert.equal(p.evidence.length,54);
  const originalGeneration=JSON.stringify(p.generations[0]);const oldEvidence=JSON.stringify(p.evidence);const parentId=p.generations[0].directions[0].id;
  p=await service.execute(owner,p.id,command(p,{action:'choose',directionId:parentId}));assert.equal(p.selectedDirectionId,parentId);
  p=await service.execute(owner,p.id,command(p,{action:'annotate',targetId:parentId,text:'Brand review note'}));assert.equal(p.annotations[parentId],'Brand review note');
  p=await service.execute(owner,p.id,command(p,{action:'revise',directionId:parentId,feedback:'Explore a local podcast campaign with clearer community voice'}));assert.equal(plannerCalls,1);assert.deepEqual([...new Set(p.operation!.steps.map(s=>s.category))],['podcast','place']);while(p.operation)p=await service.execute(owner,p.id,command(p,{action:'advance'}));
  assert.equal(p.generations.length,2);assert.equal(p.selectedDirectionId,null);assert.equal(p.generations[1].parentDirectionId,parentId);assert.match(p.generations[1].feedback!,/local podcast campaign/);assert.match(revisionPrompt,/local podcast campaign/);assert.equal(JSON.stringify(p.generations[0]),originalGeneration);assert.equal(JSON.stringify(p.evidence.slice(0,54)),oldEvidence);assert.equal(p.annotations[parentId],'Brand review note');assert.equal(qlooCalls,15);
  const revisionIds=new Set(p.evidence.slice(54).map(e=>e.id));assert.ok(p.generations[1].evidenceIds.every(id=>revisionIds.has(id)));
  p=await service.execute(owner,p.id,command(p,{action:'reject',directionId:parentId,reason:'The new direction better fits the brief'}));assert.equal(p.selectedDirectionId,null);assert.equal(p.decisions.at(-1)?.decision,'rejected');assert.equal((await store.read(owner,p.id)).generations.length,2);
 }finally{globalThis.fetch=original;}
});
test('simultaneous CAS commands have one durable winner and only its receipt',async()=>{
 const owner='concurrent-owner';const p=make();await store.create(owner,p);const a=structuredClone(p);const b=structuredClone(p);a.title='First';b.title='Second';
 const outcomes=await Promise.allSettled([store.save(owner,0,a,{commandId:'first-command',requestHash:'first'}),store.save(owner,0,b,{commandId:'second-command',requestHash:'second'})]);
 assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,1);const result=await store.read(owner,p.id);assert.equal(result.version,1);assert.equal(Number(await store.receipt(owner,p.id,'first-command','first'))+Number(await store.receipt(owner,p.id,'second-command','second')),1);
});

test('unrelated slot confirmations preserve candidates and changed relevant inputs invalidate them',async()=>{
 const owner='independent-slot-owner';let p=make();await store.create(owner,p);const first=randomToken();const second=randomToken();const entity=(id:string)=>({id,name:id,type:'urn:entity:brand',description:'',image:null,url:null});await store.putCandidate(owner,p,0,p.references[0].query,entity('first'),first);await store.putCandidate(owner,p,1,p.references[1].query,entity('second'),second);const service=new PitchProof(store,{});p=await service.execute(owner,p.id,command(p,{action:'confirm_reference',slot:0,token:first}));p=await service.execute(owner,p.id,command(p,{action:'confirm_reference',slot:1,token:second}));assert.equal(p.references[0].entity?.id,'first');assert.equal(p.references[1].entity?.id,'second');const third=randomToken();await store.putCandidate(owner,p,2,p.references[2].query,entity('third'),third);const changed=structuredClone(p);changed.brief.market='Paris';await assert.rejects(()=>store.candidate(owner,changed,2,third),e=>e instanceof AppError&&e.code==='EXPIRED_CANDIDATE');
});
test('site-wide budget stops fresh anonymous owners after the daily cap without charging owner usage',async()=>{
 const day=new Date().toISOString().slice(0,10);await db.prepare('INSERT INTO provider_usage(owner_id,day,calls) VALUES(?,?,499) ON CONFLICT(owner_id,day) DO UPDATE SET calls=499').bind('__site_total__',day).run();await store.budget('last-allowed-owner');await assert.rejects(()=>store.budget('fresh-anonymous-owner'),e=>e instanceof AppError&&e.code==='SITE_DAILY_LIMIT');assert.equal(await db.prepare('SELECT calls FROM provider_usage WHERE owner_id=? AND day=?').bind('fresh-anonymous-owner',day).first(),null);await db.prepare('UPDATE provider_usage SET calls=0 WHERE owner_id=? AND day=?').bind('__site_total__',day).run();await db.prepare('INSERT INTO provider_usage(owner_id,day,calls) VALUES(?,?,120)').bind('owner-at-cap',day).run();await assert.rejects(()=>store.budget('owner-at-cap'),e=>e instanceof AppError&&e.code==='DAILY_LIMIT');const global=await db.prepare('SELECT calls FROM provider_usage WHERE owner_id=? AND day=?').bind('__site_total__',day).first<{calls:number}>();assert.equal(global?.calls,0);
});

test('empty successful research is a disclosed completed gap while other categories continue',async()=>{
 const owner='sparse-owner';let p=confirmed();await store.create(owner,p);const service=new PitchProof(store,{QLOO_API_KEY:'key',MODEL_API_KEY:'key'});p=await service.execute(owner,p.id,command(p,{action:'start_research'}));const original=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({results:{entities:calls===1?[]:[{entity_id:'available',name:'Available evidence'}]}});};
 try{p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(p.status,'researching');assert.equal(p.operation?.steps[0].status,'complete');assert.match(p.operation?.steps[0].error??'',/evidence gap/);assert.deepEqual(p.operation?.steps[0].evidenceIds,[]);assert.equal(p.evidence.length,0);p=await service.execute(owner,p.id,command(p,{action:'advance'}));assert.equal(calls,2);assert.equal(p.evidence.length,1);assert.equal(p.operation?.steps.filter(s=>s.status==='complete').length,2);}finally{globalThis.fetch=original;}
});
test('empty Qloo search returns no candidates including documented no-result404',async()=>{
 const original=globalThis.fetch;try{globalThis.fetch=async()=>Response.json({results:[]});assert.deepEqual(await searchQloo('key','Unknown'),[]);globalThis.fetch=async()=>new Response('No results',{status:404});assert.deepEqual(await searchQloo('key','Unknown'),[]);}finally{globalThis.fetch=original;}
});
