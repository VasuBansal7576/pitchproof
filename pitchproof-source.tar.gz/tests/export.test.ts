import test from "node:test";
import assert from "node:assert/strict";
import { renderBriefHtml, renderBriefMarkdown } from "../lib/export";
import { EMPTY_BRIEF, type Direction, type Project } from "../lib/pitchproof-types";

function syntheticProject(): Project {
  const direction: Direction = {
    id: "direction-test", title: "Synthetic direction", hook: "A proposed campaign", audienceHypothesis: "A hypothesis to test",
    strategy: "A test strategy", visuals: { description: "Graphic typography", palette: ["#111111"], references: ["Synthetic film"] },
    channels: ["Social"], claims: [{ text: "Synthetic observed association", evidenceIds: ["evidence-test"] }],
    testPlan: { hypothesis: "Creative changes engagement", variants: ["Control", "Treatment"], metric: "Click-through rate", successCriterion: "Pre-register a threshold" }, limitations: ["Not a purchase prediction"],
  };
  const brief = { ...EMPTY_BRIEF, product: "Test shoe", description: "Agency facts", market: "London", audience: "Recreational runners" };
  return {
    id: "project-test", title: "Synthetic brief", version: 1, status: "ready", brief, references: [],
    evidence: [{ id: "evidence-test", runId: "run-test", category: "artist", entity: { id: "synthetic-artist", name: "Synthetic artist", type: "urn:entity:artist", description: "", image: null, url: null }, rank: 2,
      score: { value: 0.72, metric: "affinity" }, observation: "A synthetic association for testing", collectedAt: "2026-10-24T00:00:00Z",
      context: { referenceNames: ["Synthetic brand"], referenceIds: ["synthetic-brand"], referenceRoles: ["aesthetic"], market: "London", geographyApplied: false, parameters: { "filter.type": "urn:entity:artist" }, endpoint: "/v2/insights" } }],
    generations: [{ id: "generation-test", createdAt: "2026-10-24T00:00:00Z", model: "synthetic-test-model", directions: [direction], evidenceIds: ["evidence-test"], parentDirectionId: null, feedback: null, brief }],
    selectedDirectionId: null, decisions: [], annotations: {}, operation: null, error: null, createdAt: "2026-10-24T00:00:00Z", updatedAt: "2026-10-24T00:00:00Z",
  };
}

test("HTML export escapes agency and provider content instead of executing it", () => {
  const project = syntheticProject();
  project.title = '<script>alert("brief")</script>';
  project.evidence[0].observation = '<img src=x onerror="alert(1)">';
  project.annotations["direction-test"] = '<script>alert("annotation")</script>';
  const html = renderBriefHtml(project);
  assert.ok(html.includes("&lt;script&gt;"));
  assert.ok(html.includes("&lt;img"));
  assert.ok(!html.includes("<script>"));
  assert.ok(!html.includes("<img src=x"));
});

test("exports retain score context and separate agency annotation from evidence", () => {
  const project = syntheticProject();
  project.annotations["evidence-test"] = "Agency opinion";
  const markdown = renderBriefMarkdown(project);
  assert.ok(markdown.includes("affinity: 0.72"));
  assert.ok(markdown.includes("not a purchase probability"));
  assert.ok(markdown.includes("Geographic filtering was not applied"));
  assert.ok(markdown.includes("Agency annotation: Agency opinion"));
  assert.equal(project.evidence[0].observation, "A synthetic association for testing");
});

test("export uses frozen generation brief after current draft changes", () => {
  const project = syntheticProject();
  project.brief = { ...project.brief, product: "Changed unresearched product" };
  project.title = "Changed unresearched product";
  assert.ok(renderBriefMarkdown(project).includes("Product: Test shoe"));
  assert.ok(!renderBriefMarkdown(project).includes("Changed unresearched product"));
  assert.ok(!renderBriefHtml(project).includes("Changed unresearched product"));
});

test("an explicitly selected historical direction exports its own frozen brief", () => {
  const project = syntheticProject();
  const newer = structuredClone(project.generations[0]);
  newer.id = "newer-generation";
  newer.brief.product = "Newer shoe";
  newer.directions[0].id = "newer-direction";
  newer.directions[0].title = "Newer campaign";
  project.generations.push(newer);
  project.selectedDirectionId = "direction-test";
  const markdown = renderBriefMarkdown(project);
  assert.ok(markdown.startsWith("# Test shoe"));
  assert.ok(!markdown.includes("Newer campaign"));
  assert.ok(!renderBriefHtml(project).includes("Newer campaign"));
});

test("selected direction export excludes other campaign directions", () => {
  const project = syntheticProject();
  project.generations[0].directions.push({ ...project.generations[0].directions[0], id: "second", title: "Excluded direction" });
  project.selectedDirectionId = "direction-test";
  assert.ok(!renderBriefHtml(project).includes("Excluded direction"));
  assert.ok(!renderBriefMarkdown(project).includes("Excluded direction"));
});

test("a project without generated directions cannot export a finished brief", () => {
  const project = syntheticProject();
  project.generations = [];
  assert.throws(() => renderBriefHtml(project), /Generate campaign directions/);
  assert.throws(() => renderBriefMarkdown(project), /Generate campaign directions/);
});
