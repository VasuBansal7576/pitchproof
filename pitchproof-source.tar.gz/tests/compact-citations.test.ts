import assert from 'node:assert/strict';
import { test } from 'node:test';
import type { Evidence } from '../lib/pitchproof-types';
import { AppError } from '../server/errors';
import { makeOperation, makeProject } from '../server/pitchproof';
import { synthesize } from '../server/providers/synthesis';
import { parseProjectInput } from '../server/validation';

function fixture() {
  const project = makeProject(parseProjectInput({
    brief: { product: 'Campaign test', description: 'A city campaign', category: 'Footwear', market: 'London', audience: 'City residents', objective: 'Launch', constraints: '', website: '' },
    references: [{ query: 'Seed brand', role: 'aesthetic' }, { query: 'Second seed', role: 'competitor' }, { query: 'Third seed', role: 'audience' }],
  }));
  project.references.forEach((reference, index) => {
    reference.entity = { id: `seed-${index}`, name: reference.query, type: 'urn:entity:brand', description: '', image: null, url: null };
  });
  const operation = makeOperation(project, 'research');
  const evidence: Evidence[] = Array.from({ length: 6 }, (_, index) => ({
    id: `a945aa81-506e-4bd8-8806-${String(index).padStart(12, '0')}`, runId: operation.id, category: index % 2 ? 'artist' : 'brand',
    entity: { id: `d5126444-2989-418d-947e-${String(index).padStart(12, '0')}`, name: `Observed ${index}`, type: 'urn:entity:brand', description: '', image: null, url: null },
    rank: index + 1, score: null, observation: `Canonical association ${index}.`, collectedAt: project.createdAt,
    context: { referenceNames: ['Seed brand'], referenceIds: ['seed-0'], referenceRoles: ['aesthetic'], market: 'London', geographyApplied: false, parameters: {}, endpoint: '/v2/insights' },
  }));
  return { project, operation, evidence };
}

function output(ids = ['E1', 'E6']) {
  return { directions: Array.from({ length: 3 }, (_, index) => ({
    title: `Direction ${index}`, hook: `A distinct creative hook ${index}`, audienceHypothesis: 'An audience hypothesis to test', strategy: 'A proposed creative interpretation',
    visuals: { description: 'A proposed visual treatment', palette: ['#112233', '#445566', '#778899'], references: ['Observed 0'] },
    channels: ['Organic social'], evidenceIds: ids,
    testPlan: { hypothesis: 'A seven-day pilot with equal exposure', variants: ['First creative treatment', 'Second creative treatment'], metric: 'Qualified click-through rate', successCriterion: 'A proposed relative lift decision rule' },
    limitations: ['Associations are not causal proof', 'Customer preferences require validation'],
  })) };
}

async function withModel(ids: string[], run: (request: () => ReturnType<typeof synthesize>) => Promise<void>) {
  const { project, operation, evidence } = fixture();
  const original = globalThis.fetch;
  globalThis.fetch = async (_url, init) => {
    const body = JSON.parse(String(init?.body));
    const payload = JSON.parse(body.input);
    assert.deepEqual(payload.evidence.map((record: Evidence) => record.id), ['E1', 'E2', 'E3', 'E4', 'E5', 'E6']);
    assert.deepEqual(payload.evidence.map((record: Evidence) => record.entity.id), evidence.map(record => record.entity.id));
    assert.match(body.system_instruction, /exact top-level id strings/);
    return Response.json({ status: 'completed', steps: [{ type: 'model_output', content: [{ type: 'text', text: JSON.stringify(output(ids)) }] }] });
  };
  try {
    await run(() => synthesize({ MODEL_API_KEY: 'synthetic-key', MODEL_NAME: 'gemini-3.5-flash-lite' }, operation, evidence, project));
  } finally { globalThis.fetch = original; }
}

test('short model-local evidence citations resolve to canonical immutable records', async () => {
  const { evidence } = fixture();
  await withModel(['E1', 'E6'], async request => {
    const directions = await request();
    for (const direction of directions) {
      assert.deepEqual(direction.claims, [evidence[0], evidence[5]].map(record => ({ text: record.observation, evidenceIds: [record.id] })));
      assert.ok(direction.claims.every(claim => !claim.evidenceIds[0].startsWith('E')));
    }
  });
});

test('unknown aliases, raw entity IDs, canonical IDs and prior-run IDs cannot become citations', async () => {
  const { evidence } = fixture();
  for (const invalid of ['E0', 'E7', 'e1', 'E01', ' E1 ', evidence[0].entity.id, evidence[0].id, 'previous-run-evidence']) {
    await withModel(['E1', invalid], async request => {
      await assert.rejects(request, error => error instanceof AppError && error.code === 'INVALID_CITATIONS');
    });
  }
});

test('duplicate short aliases remain invalid after canonical mapping', async () => {
  await withModel(['E1', 'E1'], async request => {
    await assert.rejects(request, error => error instanceof AppError && error.code === 'INVALID_CITATIONS');
  });
});
