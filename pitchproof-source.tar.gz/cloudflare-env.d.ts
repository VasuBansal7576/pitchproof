declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    QLOO_API_KEY?: string;
    MODEL_API_KEY?: string;
    MODEL_PROVIDER?: string;
    MODEL_NAME?: string;
  }
}
