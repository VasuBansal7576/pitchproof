export const CATEGORIES = ["brand", "artist", "movie", "place", "podcast"] as const;
export const TEXT_LIMITS = { product: 160, description: 2000, category: 160, market: 160, audience: 1000, objective: 1000, constraints: 1000, website: 300, reference: 150, feedback: 2000, annotation: 2000 } as const;
export type Category = (typeof CATEGORIES)[number];
export type ReferenceRole = "competitor" | "aesthetic" | "audience";
export type Brief = {
  product: string;
  description: string;
  category: string;
  market: string;
  audience: string;
  objective: string;
  constraints: string;
  website: string;
};
export type Entity = {
  id: string;
  name: string;
  type: string;
  description: string;
  image: string | null;
  url: string | null;
};
export type Reference = {
  query: string;
  role: ReferenceRole;
  entity: Entity | null;
};
export type Candidate = { entity: Entity; token: string };
export type Evidence = {
  id: string;
  runId: string;
  category: Category;
  entity: Entity;
  rank: number;
  score: { value: number; metric: string } | null;
  observation: string;
  collectedAt: string;
  context: {
    referenceNames: string[];
    referenceIds: string[];
    referenceRoles: ReferenceRole[];
    market: string;
    geographyApplied: boolean;
    parameters: Record<string, string>;
    endpoint: string;
  };
};
export type Direction = {
  id: string;
  title: string;
  hook: string;
  audienceHypothesis: string;
  strategy: string;
  campaign?: {
    device?: "participation" | "story" | "product_discovery";
    proposition: string;
    audienceTension: string;
    productRole: string;
    mechanism: string;
    execution: string;
    callToAction: string;
    evidenceBridge: { evidenceId: string; interpretation: string; relevance: string; uncertainty: string }[];
  };
  visuals: { description: string; palette: string[]; references: string[] };
  channels: string[];
  claims: { text: string; evidenceIds: string[] }[];
  testPlan: {
    hypothesis: string;
    variants: string[];
    metric: string;
    successCriterion: string;
    kind?: "concept" | "execution";
    variable?: string;
    controls?: string;
    budget?: string;
    minimumData?: string;
    inconclusive?: string;
  };
  limitations: string[];
};
export type Generation = {
  id: string;
  createdAt: string;
  model: string;
  directions: Direction[];
  evidenceIds: string[];
  parentDirectionId: string | null;
  feedback: string | null;
  brief: Brief;
  references?: Reference[];
};
export type ResearchStep = {
  id: string;
  category: Category;
  seedIds: string[];
  seedNames: string[];
  seedRoles: ReferenceRole[];
  status: "pending" | "complete" | "failed";
  evidenceIds: string[];
  error: string | null;
};
export type Operation = {
  id: string;
  kind: "research" | "revision";
  phase: "research" | "synthesis";
  state: "pending" | "running" | "failed";
  steps: ResearchStep[];
  brief: Brief;
  references: Reference[];
  feedback: string | null;
  parentDirectionId: string | null;
  leaseToken: string | null;
  leaseUntil: number;
  error: string | null;
  failureCode?: string | null;
  startedAt: string;
};
export type Project = {
  id: string;
  title: string;
  version: number;
  status: "draft" | "researching" | "ready" | "error";
  brief: Brief;
  references: Reference[];
  evidence: Evidence[];
  generations: Generation[];
  selectedDirectionId: string | null;
  decisions: { directionId: string; decision: "selected" | "rejected"; reason: string; createdAt: string }[];
  annotations: Record<string, string>;
  operation: Operation | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
};
export type ProjectSummary = Pick<Project, "id" | "title" | "status" | "createdAt" | "updatedAt" | "version"> & {
  category: string;
  market: string;
  directionCount: number;
  evidenceCount: number;
};
export type Configuration = {
  qlooConfigured: boolean;
  modelConfigured: boolean;
  modelName: string;
  modelProvider: string;
  storageConfigured: boolean;
};
export type Command =
  | { action: "update_brief"; brief: Brief; references: { query: string; role: ReferenceRole }[] }
  | { action: "confirm_reference"; slot: number; token: string }
  | { action: "start_research" }
  | { action: "advance" }
  | { action: "retry" }
  | { action: "cancel" }
  | { action: "revise"; directionId: string; feedback: string }
  | { action: "choose"; directionId: string }
  | { action: "reject"; directionId: string; reason: string }
  | { action: "annotate"; targetId: string; text: string };
export type CommandEnvelope = Command & { expectedVersion: number; commandId: string };
export type ApiFailure = { error: string; code: string; details?: unknown };
export const EMPTY_BRIEF: Brief = {
  product: "", description: "", category: "Running footwear", market: "", audience: "",
  objective: "Launch a new product", constraints: "", website: "",
};
export function latestGeneration(project: Project): Generation | null {
  return project.generations.at(-1) ?? null;
}
