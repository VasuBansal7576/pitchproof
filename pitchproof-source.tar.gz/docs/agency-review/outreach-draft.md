# Agency review invitation draft

Unsent draft for the user to personalize and send. No recipient has been researched or contacted.

Subject: Could you review a campaign brief workflow?

Hi [name],

I am building PitchProof for independent creative agencies. It turns a brief and confirmed reference brands into campaign directions linked to Qloo cultural association records. You can reject options, request a researched revision, and export the selected direction with your notes.

Could you spend about 25 minutes testing it with a hypothetical or non-confidential brief? I want to learn whether the evidence changes a creative decision and whether the revision follows your feedback. The app is at https://pitchproof-studio.zippy17.chatgpt.site.

The cultural connections are research hypotheses. They do not prove customer preferences or grant advertising rights to referenced artists, films, or brands. I am asking for candid feedback. I would seek separate permission before quoting you or naming your agency.

If the workflow is useful, we can discuss a pilot after commercial usage rights are verified.

Thanks,
Vasu
