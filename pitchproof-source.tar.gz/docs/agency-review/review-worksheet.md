# Agency review worksheet

Blank worksheet. No participant response, endorsement, review, or payment is recorded here.

| Field | Reviewer response |
| --- | --- |
| Date and tested build | |
| Reviewer role and optional organization | |
| Browser and device | |
| Brief and permission to use it | |
| Direction considered before PitchProof | |
| Task completed or exact stopping point | |

Answer in your own words.

1. Which decision changed after you saw the proposals or evidence? If none changed, what was missing?
2. Which direction did you reject, and why? Did the evidence help you explain the rejection?
3. Was the connection between the Qloo observation and creative proposal useful? Identify one concrete connection that worked and one that did not.
4. Which claim sounded stronger than its evidence? Did any proposal imply an unsupported product fact, endorsement, or known customer preference?
5. What feedback did you give? Which parts of the revision preserved, changed, or ignored your intent?
6. Did the new evidence help the revision? Could you distinguish fresh research from the previous generation?
7. Did your selected brief retain the notes and evidence needed for a client discussion? What did you still have to rewrite?
8. Would you use this on another permitted brief? State the situation and the reason.

Only after commercial rights have been verified, discuss a paid pilot separately.

| Commercial follow-up | Response |
| --- | --- |
| Rights verification reference and date | |
| Paid problem the pilot would test | |
| Proposed deliverable and acceptance condition | |
| Proposed price and who controls budget | |
| Hypothetical interest, agreed scope, or actual payment | |
| Permission to follow up | |
| Separate permission for any public quotation | |

An empty field is unknown. Do not infer approval or willingness to pay from silence.
