# Run an agency review

Use this protocol to test whether PitchProof helps an independent creative agency choose and explain a campaign direction. No external agency review has occurred in the evidence inspected for this package.

1. Invite one agency strategist or creative director to review a non-confidential brief.
2. Ask the reviewer to record an initial direction before opening PitchProof.
3. Let the reviewer enter the brief and confirm the reference entities in their own browser session.
4. Ask the reviewer to compare the directions and open the evidence behind at least one strong and one weak proposal.
5. Ask the reviewer to reject one option with a reason.
6. Ask the reviewer to give feedback and assess the revised options against that feedback.
7. Ask the reviewer to choose a direction and write a production note.
8. Ask the reviewer to inspect the selected Markdown or printable brief.
9. Complete [the review worksheet](review-worksheet.md) in the reviewer's own words.
10. Record the build, date, browser, task outcome, and any failure alongside the worksheet.

Distinguish observed task completion from an opinion about usefulness. Keep participant quotations exact. Obtain separate permission before using a name, employer, quotation, or endorsement publicly. A review invitation, internal technical review, or completed worksheet is not payment validation.

Use a hypothetical brief unless the reviewer confirms permission to provide client information. Do not publish raw provider responses or confidential client work. Cultural images and named works remain reference material unless separate advertising rights permit use.

Ask about a paid pilot only after Qloo commercial access, pricing, retention, client-export rights, model terms, and asset rights have been verified. Record hypothetical willingness separately from an agreed paid scope and an actual payment. Do not enable billing as part of the review.
