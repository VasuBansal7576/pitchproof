# Official submission requirements

Checked October 26, 2026 against the [official overview](https://qloo.devpost.com/) and [official rules](https://qloo.devpost.com/rules). This is a preparation reference, not a submitted entry.

## Timing

| Event | Official time | India time |
| --- | --- | --- |
| Submission deadline | October 30, 2026 at 11:45 pm Eastern, shown as EDT | October 31 at 9:15 am IST |
| Judging starts | November 2 at noon Eastern | November 2 at 10:30 pm IST |
| Judging ends | November 5 at 11:45 pm Eastern | November 6 at 10:15 am IST |

The November conversions use EST after the daylight-saving change. The overview says the top three finalists must appear on November 5 and be available for preparation beforehand. The rules list an approximate November 5 winner announcement despite the later judging end. No exact finalist appearance time is published in the inspected overview. Preserve availability and follow organizer instructions. Sources are the [overview](https://qloo.devpost.com/) and [rules, sections 1 and 6](https://qloo.devpost.com/rules).

## Required materials and access

The entry needs a working Qloo-integrated agentic application, an externally published functional demo, a public repository with complete source and run instructions, a detectable open-source license, and an English description. Videos are optional. Judge access must remain free and without restriction through judging end. Private projects require test credentials. The entrant must hold the necessary integration and submission rights. Sources are the [overview requirements](https://qloo.devpost.com/) and [rules, section 4](https://qloo.devpost.com/rules).

## Equal judging criteria

The four criteria have equal weight. Stage one first checks viability and API fit. [Official rules, section 6](https://qloo.devpost.com/rules).

| Criterion | PitchProof evidence to present | Claim boundary |
| --- | --- | --- |
| Technological Implementation | Exact Qloo confirmation, cross-category research, fresh feedback research, canonical provenance. | A saved successful run does not guarantee future provider capacity. |
| Design | Brief, reference confirmation, comparison, evidence, decisions, revision, notes, and selected export. | The new campaign-quality update requires its own acceptance. |
| Potential Impact | A defined independent-agency pitch workflow and a review worksheet. | External agency utility, time savings, and payment remain unvalidated. |
| Quality of the Idea | Cultural associations inform creative directions and test proposals with explicit uncertainty. | The controlled reference comparison is not an LLM-only benchmark or campaign experiment. |

Recheck official pages before final entry. No registration, submission, billing change, message, or schedule was created in this document pass.
