# Keep the demo available during judging

The official rules require free judge access through November 6, 2026 at 10:15 am IST. This runbook does not guarantee vendor capacity or key validity. It does not create a monitor.

## Before entry

1. Open the published app in a fresh browser profile. Confirm that no payment or API-key entry is needed.
2. Complete one exact-reference research, generation, revision and export journey. Use the saved campaign to recover from a temporary failure without repeating completed queries.
3. Check Qloo's issued-access terms for a stated end date. Do not assume access ends at submission or continues through judging. Ask Qloo for written confirmation if it is absent.
4. Inspect the existing model account's remaining quota without exposing its key. Confirm that the configured model can serve the judge journey.
5. Review the app's owner and Site caps against expected judging use. Do not remove abuse protections or enable billing as an automatic workaround.
6. Keep the accepted recording and selected brief available as presentation evidence. A recording does not replace the required functional demo.

## During an interruption

1. Record the time and displayed error. Keep the same browser profile and project.
2. For a temporary provider or format failure, retry only the saved failed operation when appropriate. Do not start a new campaign to hide a failure or repeatedly hammer a rate-limited provider.
3. If access or capacity is exhausted, report the actual blocker. A configured flag is not proof that the vendor is available.
4. Do not claim that an application backoff is the vendor's quota reset time. Do not create a new key, accept terms or enable billing without authorization.

## Unsent Qloo confirmation draft

Recipient is ian@qloo.com, the existing access-request contact. This is a draft only. The user's earlier authorization covered the original email and monitoring, not further emails.

Subject: PitchProof judge-period API availability

Hi Ian,

Thank you for providing PitchProof's hackathon access. The public demo is at https://pitchproof-studio.zippy17.chatgpt.site. Could you confirm whether our issued hackathon access remains valid through the judging period ending November 5 at 11:45 pm Eastern, and whether there is a usage allowance or restriction we should plan for? We want judges to complete the live research and revision workflow without payment or API-key setup.

Thanks,
Vasu

## Sources

The [official rules](https://qloo.devpost.com/rules) establish the free judge-access requirement and judging period. The [official overview](https://qloo.devpost.com/) establishes the functional hosted demo and finalist appearance. Both were checked on October 26, 2026. No future uptime, quota reset or access extension has been verified.
