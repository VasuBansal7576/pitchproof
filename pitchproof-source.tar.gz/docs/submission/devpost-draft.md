# PitchProof Devpost draft

Draft only. No entry has been submitted.

## Project name

PitchProof

## Tagline

Turn a client brief into three campaign directions with traceable cultural evidence and a plan to test them.

## What it does

PitchProof helps independent creative agencies research a footwear pitch. The agency supplies product facts, an intended market and audience, and three reference brands. It confirms the exact Qloo identities before research begins.

Each new direction has a campaign proposition, audience tension, product role, actionable mechanism, concrete ad execution and call to action. A separate explanation links each interpretation to its exact saved Qloo observation and states what remains uncertain. The agency can reject an option, request fresh research, select a direction, add production notes and export the selected brief. Earlier generations remain unchanged.

## How Qloo changes the result

Qloo brand search resolves identities. Cross-category insights explore brands, places, artists, movies and podcasts according to the reference roles. Feedback starts fresh research before revision. New directions cite their own operation's evidence. The server maps short model citation labels to canonical records and supplies the original observation text. Each record retains its reference context, rank, provider metric, query parameters, endpoint, time and geographic scope.

Competitor, aesthetic and audience roles are research proxies. They do not identify actual customers. Geographic filtering applies to place queries only. Qloo associations cannot establish product facts, purchase intent, endorsements or causal campaign performance.

A historical same-brief comparison changed only the three references and produced materially different cultural evidence and proposals. It establishes reference sensitivity in that case. It is not an LLM-only comparison or evidence of better campaign performance.

## What we built

The app uses React, Vinext, Cloudflare D1, Qloo and Gemini. Durable operations retain completed research after provider or validation failures. Canonical citation checks, distinct campaign devices and an automated semantic check run before new directions enter history. Automated review remains fallible, so agency approval is explicit.

The model proposes a concept or execution comparison. The server supplies visible planning defaults for shared controls, an approval-dependent spend cap, baseline-dependent sample requirements and an inconclusive outcome. The app does not place ads or spend an advertising budget.

## Actual verification and limits

The October 26 quality pass used live Qloo research and Gemini synthesis. The uncommissioned Nike exercise retained 54 initial observations and added 36 fresh revision observations. Independent review accepted two revised proposals with production notes and rejected a third whose exterior camera shot could not reveal an internal shoe component. The selected route-sharing brief contains the production decisions. This is a working agency review workflow, not automatic approval of every generated proposal.

A separate hypothetical built-in footwear example exercised initial generation on the corrected release. All three initial directions passed independent review as proposals with required production notes. That review does not establish agency approval or customer demand. Local behavior tests use synthetic fixtures and are separate from live evidence.

The app exports actual Markdown text and printable HTML. The embedded browser blocks native downloads. Its manual select-and-copy fallback was checked against the actual Markdown export. The Copy Markdown button displayed a success message, but its immediate clipboard read did not match, so that button is not claimed as verified delivery. Real-phone testing remains open.

## Why it matters

The intended buyer is an independent agency preparing a client pitch. PitchProof gives the agency a reviewable connection between cultural research, a creative proposal and an explicit next test. We have no external agency acceptance, measured time savings, actual client campaign results or validated willingness to pay. An uncommissioned product exercise is not a client relationship or endorsement.

## Demo and source

- [Published app](https://pitchproof-studio.zippy17.chatgpt.site).
- [Public repository](https://github.com/VasuBansal7576/pitchproof).
- [Judge instructions](judge-testing.md).
- [Readiness and remaining operator decisions](readiness-review.md).

The repository provides the complete source archive, run instructions, assets, migrations, tests and MIT license. Verify final anonymous archive parity before entry. The code license does not grant Qloo commercial rights or advertising rights to third-party works. Production pricing, commercial rights and paid demand remain separate from the hackathon build.
