# Test PitchProof as a judge

Use the [published app](https://pitchproof-studio.zippy17.chatgpt.site) in a desktop browser. You do not need to enter an API key or payment details.

These instructions describe the October 26 campaign-quality workflow. Generated proposals require your review before client use.

## Keep the same browser session

The app creates a guest owner when trusted platform identity is absent. The server stores a hash of a random session token. The browser receives an HttpOnly `pitchproof_session` cookie with SameSite=Lax, a 30-day lifetime, and Secure on HTTPS. Projects remain server-side and belong to that owner. The list, project, command, and export routes check ownership.

Keep cookies enabled. Return in the same browser profile to reopen your campaigns. A private window, another browser, cleared cookies, or an expired session creates a different guest owner. A project URL alone does not grant access to its previous owner's work. When the host supplies authenticated identity, that identity owns the workspace instead. There is no verified guest recovery or cross-browser sharing workflow.

The development team's saved test campaigns are not shared judge accounts. Create your own campaign.

## Create and inspect a campaign

1. Start a campaign with product name `Judge footwear test`.
2. Enter this product description. `A hypothetical everyday running shoe brief. Performance, price, materials, and sustainability remain unverified.`
3. Set the category to `Running footwear`, the market to `New York City`, and the objective to `Launch a new product`.
4. Enter this audience. `Recreational adult runners exploring an everyday routine. Treat cultural connections as hypotheses.`
5. Enter this constraint. `Use original production. Do not invent product benefits, endorsements, demographics, or purchase probabilities.`
6. Enter Nike as a competitor, Adidas as an aesthetic reference, and Patagonia as an audience affinity reference.
7. Click **Find my references**.
8. Search each reference and confirm the exact brand match. Use **Change match** if the match is wrong.
9. Start research and keep the page open while it advances. If interrupted, reopen your campaign in the same browser and resume.
10. Compare the three directions. Open **Behind the idea** and inspect a linked record's provider observation, query-relative metric, time, reference context, and geographic scope.
11. Open **Explore the thinking & test plan**. Check which proposed treatment follows from the evidence and which statements remain hypotheses.

The sample button fills input only. It does not supply research results. The manual hypothetical brief above avoids treating sample product attributes as verified facts.

## Test decisions and a revision

1. Use **Pass** on an unsuitable direction and save a concrete reason.
2. Use **Refine with feedback** on a different direction.
3. Enter this feedback. `Research fresh artist and movie associations. Keep quiet city mornings. Change the visual treatment without inventing shoe benefits. Use original footage and audio.`
4. Click **Create a new version** and allow the fresh research to complete.
5. Compare the new generation with the earlier generation. Check that the old text and evidence remain available.
6. Select a direction that answers the feedback. Record any alternative that misses it instead of treating every generated option as approved.
7. Add **Your agency notes** with a production decision. Check the concrete ad, one pilot variable, shared controls, primary metric and the required budget and sample decisions. The visible defaults do not authorize spend or establish statistical results.
8. Save the notes and choose the direction.

The October 26 uncommissioned exercise produced fresh evidence and preserved history. Independent review accepted two revised proposals with production notes and rejected an infeasible component-reveal shot. Judge the actual revision you receive. Automated review does not guarantee that every direction is usable.

## Export and reopen

1. Open **Export brief** and choose **Download Markdown**.
2. If the browser cancels the native download, use **Your editable brief**. Select the text in **Markdown source** and use your normal Copy shortcut if the Copy Markdown button does not deliver text.
3. Confirm that the selected direction, your saved notes, and its supporting evidence appear in the text.
4. Open **Printable campaign brief** and use the browser's Print command to inspect or save a PDF.
5. Return to **All campaigns** and reopen the campaign in the same browser.

The embedded browser blocks native downloads. Manual select-and-copy matched the actual export text in the October 26 check. The Copy Markdown button showed a success message but did not match the immediate clipboard read, so the button alone is not a verified delivery path. Reference images can depend on external hosts.

If a provider, capacity, or configuration error appears, record the message and time. The app retains the draft and does not substitute sample results. Documentation preparation itself makes no provider requests. The separate live receipts record actual provider checks. Unrestricted judge access is still an operator readiness issue described in [the readiness review](readiness-review.md).
