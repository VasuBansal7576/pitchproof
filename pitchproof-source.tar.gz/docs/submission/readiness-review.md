# Submission readiness

The product improvements and judging drafts are prepared. Final technical release acceptance belongs in the saved release receipt. No Devpost entry or outreach has been sent.

## Current evidence and limits

- The quality pass added structured campaign arguments and explicit observation-to-interpretation links. Citation sets remain canonical and tied to the current research operation.
- Revision context includes the parent, its agency notes, evidence notes, earlier feedback and actual rejected propositions and mechanisms.
- Server-owned pilot defaults require agency approval, baseline-dependent sample calculations, comparable delivery and an inconclusive outcome. They make no promise of lift or statistical significance.
- The October 26 live uncommissioned exercise used 90 real Qloo observations. Its 36-record revision preserved the original generation and 54 observations. Two revised proposals passed independent review with production notes. One internal-component reveal was rejected as infeasible in its present form.
- The selected route-sharing proposal includes agency production decisions. Those notes are authored by the operator, not generated Qloo evidence or an external agency endorsement.
- A separate hypothetical sample exercised initial generation on the corrected release. All three initial directions passed independent review as proposals with required production notes. This is not external agency acceptance.
- Actual Markdown export and manual select-and-copy matched. The embedded browser blocks native downloads. The Copy Markdown success message alone did not establish clipboard delivery.
- Actual HTML, print output and narrow-screen checks need the final receipt after the observed pagination correction. Do not count an old PDF as acceptance of that correction.
- Public source parity must match the final source archive. Source discoverability requires a direct archive link, extraction instructions and the visible MIT license.

## Remaining human and vendor items

No agency has reviewed the sample. The user has no existing reviewer to introduce. Three published agency contacts and an unsent invitation are prepared in [the reviewer shortlist](../agency-review/reviewer-targets.md). Sending invitations requires explicit authorization. A reply, completed review and useful feedback are separate outcomes.

No paid commitment, measured time saving or campaign effectiveness is established. Confirm Qloo commercial rights and production pricing before selling briefs. The code license does not grant third-party advertising rights.

The demo is public and does not ask judges for payment or provider credentials. Application limits are 120 reserved provider calls per owner per day and 500 per Site per day, plus project history limits. Synthesis reserves two model calls. Vendor quotas can still interrupt use. Free, unrestricted availability throughout judging is not guaranteed by a successful test today.

Read [the judge-period availability runbook](judge-period-availability.md) before entry. The user must confirm personal eligibility, ownership and finalist availability. No billing, new credentials, legal acceptance, recurring monitor or Devpost submission was created by this quality pass.
