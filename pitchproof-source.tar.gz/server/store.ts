import { projectSummary, type Entity, type Project, type ProjectSummary } from '../lib/pitchproof-types';
import { fail, hash, now } from './errors';
export class Store {
  constructor(readonly db: D1Database) {}
  async read(owner: string, id: string): Promise<Project> {
    const row = await this.db.prepare('SELECT snapshot_json FROM projects WHERE id = ? AND owner_id = ?').bind(id, owner).first<{ snapshot_json: string }>();
    if (!row) fail(404, 'NOT_FOUND', 'Project not found.');
    return JSON.parse(row.snapshot_json) as Project;
  }
  async list(owner: string): Promise<ProjectSummary[]> {
    const rows = await this.db.prepare('SELECT snapshot_json FROM projects WHERE owner_id = ? ORDER BY updated_at DESC LIMIT 20').bind(owner).all<{ snapshot_json: string }>();
    return rows.results.map(row => projectSummary(JSON.parse(row.snapshot_json) as Project));
  }
  serialize(project: Project): string {
    const json = JSON.stringify(project);
    if (new TextEncoder().encode(json).length > 200_000 || project.evidence.length > 180 || project.generations.length > 8 || project.decisions.length > 100 || Object.keys(project.annotations).length > 100) fail(422, 'PROJECT_LIMIT', 'This project reached its history limit. Create a new project for more research.');
    return json;
  }
  async create(owner: string, project: Project): Promise<void> {
    const result = await this.db.prepare('INSERT INTO projects (id, owner_id, version, snapshot_json, updated_at) SELECT ?, ?, ?, ?, ? WHERE (SELECT COUNT(*) FROM projects WHERE owner_id = ?) < 20').bind(project.id, owner, project.version, this.serialize(project), project.updatedAt, owner).run();
    if (!result.meta.changes) fail(422, 'PROJECT_LIMIT', 'You can keep up to 20 projects.');
  }
  async receipt(owner: string, id: string, commandId: string, requestHash: string): Promise<boolean> {
    const row = await this.db.prepare('SELECT request_hash FROM command_receipts WHERE project_id = ? AND owner_id = ? AND command_id = ?').bind(id, owner, commandId).first<{ request_hash: string }>();
    if (!row) return false;
    if (row.request_hash !== requestHash) fail(409, 'COMMAND_REUSED', 'This command ID was already used for a different request.');
    return true;
  }
  async save(owner: string, previousVersion: number, project: Project, receipt?: { commandId: string; requestHash: string }): Promise<void> {
    project.version = previousVersion + 1;
    project.updatedAt = now();
    const update = this.db.prepare('UPDATE projects SET version = ?, snapshot_json = ?, updated_at = ? WHERE id = ? AND owner_id = ? AND version = ?').bind(project.version, this.serialize(project), project.updatedAt, project.id, owner, previousVersion);
    if (receipt) {
      const results = await this.db.batch([update, this.db.prepare('INSERT INTO command_receipts (project_id, owner_id, command_id, request_hash, result_version, created_at) SELECT ?, ?, ?, ?, ?, ? WHERE changes() = 1').bind(project.id, owner, receipt.commandId, receipt.requestHash, project.version, now())]);
      if (!results[0].meta.changes) fail(409, 'STALE_VERSION', 'The project changed. Reload it and try again.');
    } else {
      const result = await update.run();
      if (!result.meta.changes) fail(409, 'STALE_VERSION', 'The project changed. Reload it and try again.');
    }
  }
  async budget(owner: string): Promise<void> {
    const day = now().slice(0, 10);
    const results = await this.db.batch([
      this.db.prepare('INSERT INTO provider_usage (owner_id, day, calls) SELECT ?, ?, 1 WHERE COALESCE((SELECT calls FROM provider_usage WHERE owner_id = ? AND day = ?), 0) < 120 ON CONFLICT(owner_id, day) DO UPDATE SET calls = calls + 1 WHERE calls < 500').bind('__site_total__', day, owner, day),
      this.db.prepare('INSERT INTO provider_usage (owner_id, day, calls) SELECT ?, ?, 1 WHERE changes() = 1 ON CONFLICT(owner_id, day) DO UPDATE SET calls = calls + 1').bind(owner, day),
    ]);
    if (!results[0].meta.changes) {
      const usage = await this.db.prepare('SELECT calls FROM provider_usage WHERE owner_id = ? AND day = ?').bind(owner, day).first<{ calls: number }>();
      if ((usage?.calls ?? 0) >= 120) fail(429, 'DAILY_LIMIT', 'Your daily provider request limit has been reached.');
      fail(429, 'SITE_DAILY_LIMIT', 'The site has reached its daily provider request limit. Please return tomorrow.');
    }
  }
  async putCandidate(owner: string, project: Project, slot: number, query: string, entity: Entity, token: string): Promise<void> {
    await this.db.prepare('INSERT INTO reference_candidates (token_hash, owner_id, project_id, slot, input_hash, query, entity_json, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(await hash(token), owner, project.id, slot, await hash(JSON.stringify({ brief: project.brief, reference: project.references[slot] })), query, JSON.stringify(entity), Date.now() + 600_000).run();
  }
  async candidate(owner: string, project: Project, slot: number, token: string): Promise<{ entity: Entity; query: string }> {
    const row = await this.db.prepare('SELECT entity_json, query FROM reference_candidates WHERE token_hash = ? AND owner_id = ? AND project_id = ? AND slot = ? AND input_hash = ? AND expires_at > ?').bind(await hash(token), owner, project.id, slot, await hash(JSON.stringify({ brief: project.brief, reference: project.references[slot] })), Date.now()).first<{ entity_json: string; query: string }>();
    if (!row) fail(400, 'EXPIRED_CANDIDATE', 'Search again to confirm a current reference candidate.');
    return { entity: JSON.parse(row.entity_json) as Entity, query: row.query };
  }
}
