import { AppError, fail } from '../errors';
export async function providerJson(url: URL, init: RequestInit, provider: string, timeout = 20_000, notFoundIsEmpty = false): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal, redirect: 'error' });
    if (response.status === 404 && notFoundIsEmpty) return { results: [] };
    if (response.status === 429) fail(429, 'PROVIDER_RATE_LIMIT', `${provider} is rate limited. Retry this step later.`);
    if (response.status === 401 || response.status === 403) fail(502, 'PROVIDER_AUTH', `${provider} rejected its server credential. Check the configured key.`);
    if (!response.ok) fail(502, 'PROVIDER_ERROR', `${provider} could not complete this request (HTTP ${response.status}).`);
    const reader = response.body?.getReader();
    if (!reader) fail(502, 'PROVIDER_RESPONSE', `${provider} returned an empty response.`);
    let size = 0; const parts: Uint8Array[] = [];
    while (true) { const result = await reader.read(); if (result.done) break; size += result.value.length; if (size > 1_000_000) { await reader.cancel(); fail(502, 'PROVIDER_RESPONSE', `${provider} response exceeded the limit.`); } parts.push(result.value); }
    const merged = new Uint8Array(size); let offset = 0; for (const part of parts) { merged.set(part, offset); offset += part.length; }
    try { return JSON.parse(new TextDecoder().decode(merged)); } catch { fail(502, 'PROVIDER_RESPONSE', `${provider} returned invalid JSON.`); }
  } catch (error) {
    if (error instanceof AppError) throw error;
    fail(502, controller.signal.aborted ? 'PROVIDER_TIMEOUT' : 'PROVIDER_UNAVAILABLE', controller.signal.aborted ? `${provider} timed out. Retry this step.` : `${provider} is unavailable. Retry this step.`);
  } finally { clearTimeout(timer); }
}
