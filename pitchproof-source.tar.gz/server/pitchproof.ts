import { CATEGORIES, type Candidate, type Category, type CommandEnvelope, type Generation, type Operation, type Project, type ResearchStep } from '../lib/pitchproof-types';
import { AppError, fail, hash, now, randomToken, safeFailure, uid } from './errors';
import type { ProjectInput } from './validation';
import { Store } from './store';
import { researchQloo, searchQloo } from './providers/qloo';
import { requireProviders, revisionPlan, synthesize, modelConfiguration, type ProviderEnv } from './providers/synthesis';
export function makeProject(input: ProjectInput): Project {
  const time = now(); return { id: uid(), title: input.brief.product || 'Untitled pitch', version: 0, status: 'draft', brief: input.brief, references: input.references.map(ref => ({ ...ref, entity: null })), evidence: [], generations: [], selectedDirectionId: null, decisions: [], annotations: {}, operation: null, error: null, createdAt: time, updatedAt: time };
}
export function makeOperation(project: Project, kind: 'research' | 'revision', feedback: string | null = null, parentDirectionId: string | null = null, revisionCategories?: Category[]): Operation {
  const steps: ResearchStep[] = [];
  for (const ref of project.references) {
    if (!ref.entity) fail(422, 'REFERENCES_REQUIRED', 'Confirm all three reference brands before research.');
    const categories = revisionCategories ?? (ref.role === 'audience' ? [...CATEGORIES] : ref.role === 'competitor' ? ['brand', 'place'] as Category[] : ['artist', 'movie'] as Category[]);
    for (const category of categories) steps.push({ id: uid(), category, seedIds: [ref.entity.id], seedNames: [ref.entity.name], seedRoles: [ref.role], status: 'pending', evidenceIds: [], error: null });
  }
  return { id: uid(), kind, phase: 'research', state: 'pending', steps, brief: structuredClone(project.brief), references: structuredClone(project.references), feedback, parentDirectionId, leaseToken: null, leaseUntil: 0, error: null, failureCode: null, startedAt: now() };
}
function hasDirection(project: Project, id: string): boolean { return project.generations.some(g => g.directions.some(d => d.id === id)); }
function readyForResearch(project: Project): void {
  if (project.operation) fail(409, 'OPERATION_ACTIVE', 'Finish or cancel the current operation first.');
  if (project.references.length !== 3 || project.references.some(r => !r.entity)) fail(422, 'REFERENCES_REQUIRED', 'Confirm all three reference brands before research.');
  if (new Set(project.references.map(r => r.entity!.id)).size !== 3) fail(422, 'DISTINCT_REFERENCES', 'Use three different confirmed reference brands.');
  if (!project.brief.product.trim() || !project.brief.description.trim() || !project.brief.market.trim() || !project.brief.audience.trim()) fail(422, 'BRIEF_REQUIRED', 'Add a product, description, target market and audience before research.');
  if (project.evidence.length > 125 || project.generations.length >= 8) fail(422, 'PROJECT_LIMIT', 'This project has reached its research history limit. Create a new project.');
}
export class PitchProof {
  constructor(readonly store: Store, readonly env: ProviderEnv) {}
  async create(owner: string, input: ProjectInput): Promise<Project> { const project = makeProject(input); await this.store.create(owner, project); return project; }
  async search(owner: string, id: string, slot: number, query: string): Promise<Candidate[]> {
    const project = await this.store.read(owner, id);
    if (!this.env.QLOO_API_KEY?.trim()) fail(503, 'QLOO_NOT_CONFIGURED', 'Cultural research is not connected yet. Your brief is saved. Open provider setup or contact the workspace owner.');
    await this.store.budget(owner);
    const entities = await searchQloo(this.env.QLOO_API_KEY, query);
    const candidates: Candidate[] = [];
    for (const entity of entities) { const token = randomToken(); await this.store.putCandidate(owner, project, slot, query, entity, token); candidates.push({ entity, token }); }
    await this.store.db.prepare('DELETE FROM reference_candidates WHERE expires_at < ?').bind(Date.now()).run();
    return candidates;
  }
  async execute(owner: string, id: string, command: CommandEnvelope): Promise<Project> {
    let project = await this.store.read(owner, id);
    const requestHash = await hash(JSON.stringify(command));
    if (await this.store.receipt(owner, id, command.commandId, requestHash)) return project;
    if (project.version !== command.expectedVersion) fail(409, 'STALE_VERSION', 'The project changed. Reload it and try again.');
    const previousVersion = project.version;
    switch (command.action) {
      case 'update_brief': {
        project.references = command.references.map((ref, index) => ({ ...ref, entity: project.references[index]?.query === ref.query && project.references[index]?.role === ref.role ? project.references[index].entity : null }));
        project.brief = command.brief; project.title = command.brief.product || 'Untitled pitch'; project.operation = null; project.status = 'draft'; project.error = null; break;
      }
      case 'confirm_reference': {
        const candidate = await this.store.candidate(owner, project, command.slot, command.token);
        if (project.references.some((r, i) => i !== command.slot && r.entity?.id === candidate.entity.id)) fail(422, 'DISTINCT_REFERENCES', 'Choose a different brand for each reference.');
        project.references[command.slot] = { ...project.references[command.slot], ...candidate };
        project.operation = null; project.status = 'draft'; project.error = null; break;
      }
      case 'start_research': {
        requireProviders(this.env); readyForResearch(project); project.operation = makeOperation(project, 'research'); project.status = 'researching'; project.error = null; break;
      }
      case 'revise': {
        requireProviders(this.env); readyForResearch(project);
        if (!hasDirection(project, command.directionId)) fail(404, 'DIRECTION_NOT_FOUND', 'Direction not found.');
        await this.store.budget(owner);
        const categories = await revisionPlan(this.env, command.feedback, project, command.directionId);
        project.operation = makeOperation(project, 'revision', command.feedback, command.directionId, categories); project.status = 'researching'; project.error = null; break;
      }
      case 'cancel': { const draft = project.operation?.kind === 'research' || project.status === 'draft'; project.operation = null; project.status = !draft && project.generations.length ? 'ready' : 'draft'; project.error = null; break; }
      case 'retry': {
        if (!project.operation || project.operation.state !== 'failed') fail(409, 'NOT_RETRYABLE', 'There is no failed operation to retry.');
        if (project.operation.failureCode === 'INSUFFICIENT_EVIDENCE') fail(422, 'INSUFFICIENT_EVIDENCE', 'This run has too little supporting evidence. Cancel it and change the reference brands or target market before researching again.');
        requireProviders(this.env);
        project.operation.failureCode = null;
        project.operation.steps = project.operation.steps.map(step => step.status === 'failed' ? { ...step, status: 'pending', error: null } : step);
        project.operation.state = 'pending'; project.operation.error = null; project.operation.leaseToken = null; project.operation.leaseUntil = 0; project.status = 'researching'; project.error = null; break;
      }
      case 'advance': {
        const operation = project.operation;
        if (!operation) fail(409, 'NO_OPERATION', 'Start research before advancing.');
        if (operation.state === 'failed') fail(409, 'RETRY_REQUIRED', 'Retry the failed step before advancing.');
        if (operation.leaseUntil > Date.now() && operation.leaseToken) fail(409, 'OPERATION_BUSY', 'A research step is already running.');
        requireProviders(this.env);
        operation.leaseToken = randomToken(); operation.leaseUntil = Date.now() + (operation.phase === 'synthesis' ? 150_000 : 90_000); operation.state = 'running'; operation.error = null; project.error = null; project.status = 'researching'; break;
      }
      case 'choose': case 'reject': {
        if (!hasDirection(project, command.directionId)) fail(404, 'DIRECTION_NOT_FOUND', 'Direction not found.');
        const decision = command.action === 'choose' ? 'selected' : 'rejected';
        if (command.action === 'choose') project.selectedDirectionId = command.directionId;
        else if (project.selectedDirectionId === command.directionId) project.selectedDirectionId = null;
        project.decisions.push({ directionId: command.directionId, decision, reason: command.action === 'reject' ? command.reason : '', createdAt: now() }); break;
      }
      case 'annotate': {
        if (!hasDirection(project, command.targetId) && !project.evidence.some(e => e.id === command.targetId)) fail(404, 'TARGET_NOT_FOUND', 'Annotation target not found.');
        if (command.text.trim()) project.annotations[command.targetId] = command.text.trim(); else delete project.annotations[command.targetId]; break;
      }
    }
    try { await this.store.save(owner, previousVersion, project, { commandId: command.commandId, requestHash }); }
    catch (error) { if (await this.store.receipt(owner, id, command.commandId, requestHash)) return this.store.read(owner, id); throw error; }
    if (command.action === 'advance') project = await this.advance(owner, project);
    return project;
  }
  private async advance(owner: string, claimed: Project): Promise<Project> {
    const operation = structuredClone(claimed.operation!);
    const step = operation.phase === 'research' ? operation.steps.find(s => s.status !== 'complete') : undefined;
    let evidence: Awaited<ReturnType<typeof researchQloo>> | null = null;
    let generation: Generation | null = null;
    let failure: AppError | null = null;
    try {
      await this.store.budget(owner);
      if (step) evidence = await researchQloo(this.env.QLOO_API_KEY, operation, step);
      else {
        const records = claimed.evidence.filter(e => e.runId === operation.id);
        await this.store.budget(owner);
        const directions = await synthesize(this.env, operation, records, claimed);
        generation = { id: uid(), createdAt: now(), model: `${modelConfiguration(this.env).provider}/${modelConfiguration(this.env).model}`, directions, evidenceIds: records.map(record => record.id), parentDirectionId: operation.parentDirectionId, feedback: operation.feedback, brief: structuredClone(operation.brief), references: structuredClone(operation.references) };
      }
    } catch (error) { failure = safeFailure(error); }
    for (let attempt = 0; attempt < 5; attempt++) {
      const current = await this.store.read(owner, claimed.id);
      if (current.operation?.id !== operation.id || current.operation.leaseToken !== operation.leaseToken) return current;
      const version = current.version;
      const active = current.operation;
      active.leaseToken = null; active.leaseUntil = 0;
      if (failure) {
        active.state = 'failed'; active.error = failure.message; active.failureCode = failure.code; current.status = 'error'; current.error = failure.message;
        const failedStep = active.steps.find(s => s.id === step?.id); if (failedStep) { failedStep.status = 'failed'; failedStep.error = failure.message; }
      } else if (evidence && step) {
        const completed = active.steps.find(s => s.id === step.id)!;
        completed.status = 'complete'; completed.error = evidence.length ? null : 'Qloo returned no usable entities for this category and reference. This evidence gap is excluded from synthesis.'; completed.evidenceIds = evidence.map(e => e.id); current.evidence.push(...evidence);
        active.state = 'pending'; if (active.steps.every(s => s.status === 'complete')) active.phase = 'synthesis';
      } else if (generation) { current.generations.push(generation); current.selectedDirectionId = null; current.operation = null; current.status = 'ready'; current.error = null; }
      try { await this.store.save(owner, version, current); return current; }
      catch (error) {
        if (error instanceof AppError && error.code === 'STALE_VERSION') continue;
        if (error instanceof AppError && error.code === 'PROJECT_LIMIT' && !failure) { failure = error; evidence = null; generation = null; continue; }
        throw error;
      }
    }
    return this.store.read(owner, claimed.id);
  }
}
